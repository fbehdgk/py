# 변수 : 값을 저장하는곳
# 변수의 이름이 겹치면 덮어쓴다.  -> 겹치면 안된다.
# 변수의 이름은 가독성좋게

# = : 대입 (오른쪽에서 왼쪽으로)
# == : 같다


#올해의 년도를 저장하는 변수를 정의해라

this_year = 2024

#현재 살고있는 도시를 저장하는 변수를 정의해라
residence = "incheon"

#서울의 위도는 37.33, 경도는 127.00이다
#서울의 위도와 경도를 저장하고 위도를 1증가해 출력
latitude_of_seoul = 37.33
longitude_of_seoul = 127.00
latitude_of_seoul += 1
print(latitude_of_seoul)



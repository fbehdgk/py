#입력 받기 input()
#name = input('이름 입력 : ')
#print("이름은 :", name)
#print("이름은 : " + name)
#f-문자열 [상당히 편함]
#print(f'이름은 : {name}')

#취미를 입력받아 출력하시오
#hobby = input("당신의 취미는? : ")
#print(f"취미는 {hobby} 입니다.")

#이름과 나이를 입력받아 출력
#name = input("당신의 이름 : ")
#old = input("당신의 나이 : ")
#print(f"당신의 이름은 {name}이며 나이는 {old}살 입니다.")

#함수는 1가지 일만담당 재사용이 편함

#숫자를 2개 입력받아 더해서 출력
num1 = input("첫번째 수 : ")
num2 = input("두번째 수 : ")
sum = int(num1) + int(num2)

print(f"합계 : {sum}")
#입력은 str형의 출력값이다.

#None은 빈값

# cnt + alt + shift :  다중입력
import random
member = []
member.append("전우치")
member.append("홍길동")
member.append("심봉사")
member.append("임꺽정")

random.shuffle(member) #데이터 셔플
print(member)


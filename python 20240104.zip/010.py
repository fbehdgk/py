#숫자를 입력받아 양수,음수,0을 출력

#number = int(input("숫자 : "))
#
#if number > 0:
#    print("양수")
#elif number == 0:
#    print("0")
#else:
#    print("음수")

#점수를 입력받아 70~90 이면 추천대상, 아니면
# "대상아님"이라고출력
    
number2 = int(input("숫자 : "))

if number2 >=70 and number2 <=90:
    print("추천대상")
else:
    print("대상아님")
#module : vscode의 확장프로그램 <library(기능) <framework(기능 + 사용법)

import random

#print(random.random()) 

#a= random.random() #1보다 작은실수

#b = a * 10

#for i in range(5): #range(5) 는 0,1,2,3,4 생성 / 이쁘게 작성가능
#    print(int(random.random() * 10))

#0~10사이의 랜덤정수 출력 (확률 같은가?)

print(int(random.random() * 11))

#1~10사이의 랜덤정수 출력
print(int((random.random()* 10))+1)


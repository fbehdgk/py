#길이를 입력받아 센티미터 또는 인치로 변환 출력
#길이가 양수면 인치
#음수면 센치로

#length = int(input("길이 : "))
#
#if length > 0: #인치로 변환
#    result = length / 2.54
#    print(f"센치 -> 인치로 변환 끝 {result}inch")
#elif length < 0:
#    result = -(length * 2.54)
#    print(f"인치 -> 센치로 변환 끝 {result}cm")
#else:
#    print("0은 양수,음수가 아님")

#scope : 변수를 사용할 수 있는 범위
# 블록이 스코프를 생성하는 언어 : 자바
# 함수가 스코프를 생성하는 언어 : 파이썬


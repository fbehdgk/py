리스트 = [10,20,30,40]
length = len(리스트) #길이 출력

#len  쓰지말고 길이를 측정해보자


count = 0

for item in 리스트:
    count += 1

print(count)



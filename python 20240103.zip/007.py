num = 70
#num이 0이상인지 출력

print(num >= 0)

#num이 100이하

print(num <= 100)

#num이 0~100사이인가?

print(num >= 0 and num <=100)
print(0<=num<=100) #이것도 가능은 함

#num이 0보다 작거나 100보다 큰가?
print(num < 0 or num >100)
print(not(num >= 0 and num <=100))


#사용자 ->(요청) 서버
#서버 ->(응답) 사용자
#응답 404 = not found
#서버 <--> 처리(비지니스업무)[처리부분은 서버마다 내부구조가 많이다름]
#생산성을 위해 프레임워크를 사용하기도함
#framework를 이용하는게 직접 만드는것보다 빠르고 그 종류마다 쓰는 언어가다름
#framework는 프론트/ 백엔드에 걸쳐 넓게 있다.
#프론트 html css java-script
#백 -java(처리구현 -python) / java-script도 백가능은함
#프론트 백 둘 다 하는걸 풀스택이라고함
#쇼핑몰을 구현했다기보단 정의했다고 하는게 맞다.


#기본 type : 처리할 수 있는 데이터의 종류
#            문자열,숫자,참거짓
#자바스크립트 : string,number,bool
#파이썬 : str,int,float,bool
#       모듈로 확장
import datetime #이런식으로 필요한 모듈을 가져옴

#오라클 : char, number, date

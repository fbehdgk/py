#변수
#값에다 이름을 붙여넣은것, 재활용하기위해, 구별위해
PI = 3.14 #상수 값을 바꾸지말자
pi = 3.14 #변수 값을 바꿔도 된다.

#나의 현재 위치
my_current_location  = '인천'
myCurrentLocation  = '인천'
MyCurrentLocation  = '인천'

#삼성주식을 샀다. 5만원에 10주
#현재 내 금액을 출력하시오

samsung_stock_price = 77900
my_samsung_stock_price =  50000
my_samsung_stock_count = 10

my_total_assets = my_samsung_stock_count * my_samsung_stock_price
my_profit_amount = (samsung_stock_price - my_samsung_stock_price) * my_samsung_stock_count
print(f"나의 총 손익금액은 : {my_profit_amount} | 나의 총 자산은 : {my_total_assets}")



#비교연산 (보통 조건1개)
kor,eng = 75,80
print(kor >70, kor>=70)
print(kor <70, kor<=70)
print(kor==70, kor!=70)

#논리연산 (보통 조건 2개)
print(not kor>70) #False  나옴
#조건들을 연결
#and : 하나만 거짓이면 거짓
#or : 하나만 참이면 참
#pair programming


username = input("아이디 입력 : ")
nai = input("나이입력 : ")
print(type(username))
print(type(nai))
#함수는 최소한의 기능을 한다.
#사용자에게 입력받은 값의 타입은 str형이다.
#개발자가 필요하면 타입을 바꿔준다.
nai = int(nai)
print(type(nai))
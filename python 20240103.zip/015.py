#국어 영어 모두 70이상이면 합격, 아니면 불합격
kor, eng = 75,

if kor >= 70 and eng >= 70:
    print("합격")
else:
    print("불합격")


    
